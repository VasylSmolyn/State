﻿using State.Context;

Steak steak = new Steak("T-Bone");

steak.IncreaseTemperature(48.9);
steak.IncreaseTemperature(10);
steak.IncreaseTemperature(5);
steak.DecreaseTemperature(15);
steak.DecreaseTemperature(5);
steak.IncreaseTemperature(5);
steak.IncreaseTemperature(10);
steak.IncreaseTemperature(20);
steak.IncreaseTemperature(5);
steak.IncreaseTemperature(10);
steak.IncreaseTemperature(30);
steak.IncreaseTemperature(30);